---
layout: post
title: "Buenas prácticas de seguridad en el correo electrónico"
---

Evita abrir enlaces sospechosos, verifica siempre el remitente y utiliza autenticación de doble factor.

---
layout: post
title: "El uso de sandbox en ciberseguridad"
---

Las sandboxes permiten ejecutar malware en entornos controlados para entender su comportamiento sin riesgo.
